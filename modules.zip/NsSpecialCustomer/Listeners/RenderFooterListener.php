<?php

namespace Modules\NsSpecialCustomer\Listeners;

use App\Events\RenderFooterEvent;
use Modules\NsSpecialCustomer\Services\SpecialCustomerService;

class RenderFooterListener
{
    private SpecialCustomerService $specialCustomerService;

    public function __construct(SpecialCustomerService $specialCustomerService)
    {
        $this->specialCustomerService = $specialCustomerService;
    }

    public function handle(RenderFooterEvent $event): void
    {
        if ($event->routeName === 'ns.dashboard.pos') {
            $event->output->addView('NsSpecialCustomer::pos-footer');
        }
    }
}

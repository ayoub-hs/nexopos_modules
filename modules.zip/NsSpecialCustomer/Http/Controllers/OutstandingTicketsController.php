<?php

namespace Modules\NsSpecialCustomer\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Modules\NsSpecialCustomer\Services\OutstandingTicketPaymentService;
use Modules\NsSpecialCustomer\Services\SpecialCustomerService;

class OutstandingTicketsController extends Controller
{
    public function __construct(
        private readonly SpecialCustomerService $specialCustomerService,
        private readonly OutstandingTicketPaymentService $paymentService
    ) {
    }

    public function index(Request $request): View|RedirectResponse
    {
        if (!ns()->allowedTo('special.customer.manage') && !ns()->allowedTo('special.customer.pay-outstanding-tickets')) {
            return redirect()->route('ns.dashboard.home')
                ->with('error', __('You do not have permission to access this page.'));
        }

        $groupId = $this->specialCustomerService->getSpecialGroupId();
        $customers = Customer::query()
            ->when($groupId, function ($query) use ($groupId) {
                $query->where('group_id', $groupId);
            })
            ->orderBy('first_name')
            ->orderBy('last_name')
            ->get();

        $selectedCustomer = null;
        $orders = collect();

        if ($request->filled('customer_id')) {
            $selectedCustomer = $customers->firstWhere('id', (int) $request->customer_id);

            if ($selectedCustomer) {
                $orders = Order::query()
                    ->with('payments')
                    ->where('customer_id', $selectedCustomer->id)
                    ->whereIn('payment_status', [
                        Order::PAYMENT_UNPAID,
                        Order::PAYMENT_PARTIALLY,
                    ])
                    ->orderByDesc('created_at')
                    ->get()
                    ->map(function (Order $order) {
                        $paidAmount = $order->payments->sum('value');
                        $order->paid_amount = $paidAmount;
                        $order->due_amount = max(0, (float) $order->total - $paidAmount);

                        return $order;
                    })
                    ->filter(fn (Order $order) => $order->due_amount > 0)
                    ->values();
            }
        }

        return view('NsSpecialCustomer::outstanding-tickets', [
            'customers' => $customers,
            'selectedCustomer' => $selectedCustomer,
            'orders' => $orders,
        ]);
    }

    public function pay(Request $request): RedirectResponse
    {
        if (!ns()->allowedTo('special.customer.pay-outstanding-tickets')) {
            return redirect()->route('ns.dashboard.home')
                ->with('error', __('You do not have permission to access this page.'));
        }

        $validated = $request->validate([
            'customer_id' => 'required|integer|exists:nexopos_customers,id',
            'order_id' => 'required|integer|exists:nexopos_orders,id',
        ]);

        try {
            $this->paymentService->payOutstanding(
                customerId: (int) $validated['customer_id'],
                orderId: (int) $validated['order_id'],
                authorId: (int) auth()->id()
            );

            return redirect()
                ->route('ns.dashboard.special-customer-outstanding', [
                    'customer_id' => $validated['customer_id'],
                ])
                ->with('success', __('Outstanding ticket paid successfully.'));
        } catch (\Throwable $exception) {
            return redirect()
                ->route('ns.dashboard.special-customer-outstanding', [
                    'customer_id' => $validated['customer_id'],
                ])
                ->with('error', $exception->getMessage());
        }
    }
}

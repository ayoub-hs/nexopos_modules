<?php

namespace Modules\NsSpecialCustomer\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Str;
use TorMorten\Eventy\Facades\Events as Hook;
use Modules\NsSpecialCustomer\Services\SpecialCustomerService;
use Modules\NsSpecialCustomer\Services\CashbackService;
use Modules\NsSpecialCustomer\Services\WalletService;
use Modules\NsSpecialCustomer\Services\AuditService;
use Modules\NsSpecialCustomer\Crud\SpecialCashbackCrud;
use Modules\NsSpecialCustomer\Crud\CustomerTopupCrud;
use Modules\NsSpecialCustomer\Crud\SpecialCustomerCrud;
use Modules\NsSpecialCustomer\Listeners\RenderFooterListener;
use App\Events\RenderFooterEvent;
use App\Events\SettingsSavedEvent;
use App\Models\Customer;

class NsSpecialCustomerServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register middleware
        $router = $this->app['router'];
        $router->aliasMiddleware('ns.special-customer.permission', \Modules\NsSpecialCustomer\Http\Middleware\CheckSpecialCustomerPermission::class);

        // Register services as singletons for performance
        $this->app->singleton(SpecialCustomerService::class, function ($app) {
            return new SpecialCustomerService($app->make(\App\Services\Options::class));
        });

        $this->app->singleton(CashbackService::class, function ($app) {
            return new CashbackService(
                $app->make(SpecialCustomerService::class),
                $app->make(WalletService::class)
            );
        });

        $this->app->singleton(WalletService::class, function ($app) {
            return new WalletService(
                $app->make(\App\Services\CustomerService::class),
                $app->make(AuditService::class)
            );
        });
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->loadViewsFrom(__DIR__ . '/../Resources/Views', 'NsSpecialCustomer');
        $this->loadRoutesFrom(__DIR__ . '/../Routes/api.php');
        $this->loadRoutesFrom(__DIR__ . '/../Routes/web.php');
        
        // Load module permissions (legacy format)
        if (defined('NEXO_CREATE_PERMISSIONS')) {
            include_once dirname(__FILE__) . '/../Database/Permissions/special-customer.php';
        }

        // Load new permission migration
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');

        // View composer for all module views
        View::composer('NsSpecialCustomer::*', function ($view) {
            $view->with('specialCustomerConfig', app(SpecialCustomerService::class)->getConfig());
        });

        // Register CRUD resources
        Hook::addFilter('ns-crud-resource', function ($identifier) {
            switch ($identifier) {
                case 'ns.special-customers':
                    return SpecialCustomerCrud::class;
                case 'ns.special-customer-cashback':
                    return SpecialCashbackCrud::class;
                case 'ns.special-customer-topup':
                    return CustomerTopupCrud::class;
            }
            return $identifier;
        });

        // Dashboard Menu with proper structure
        Hook::addFilter('ns-dashboard-menus', function ($menus) {
            $menus[] = [
                'label' => 'Special Customer',
                'icon' => 'la-star',
                'childrens' => [
                    ['label' => 'Customer List', 'href' => url('/dashboard/special-customer/customers')],
                    ['label' => 'Top-up Account', 'href' => url('/dashboard/special-customer/topup')],
                    ['label' => 'Outstanding Tickets', 'href' => url('/dashboard/special-customer/outstanding-tickets')],
                    ['label' => 'Cashback History', 'href' => url('/dashboard/special-customer/cashback')],
                    ['label' => 'Statistics', 'href' => url('/dashboard/special-customer/statistics')],
                ]
            ];
            return $menus;
        });

        Hook::addFilter('ns-pos-settings-tabs', function ($tabs) {
            $tabs['special_customer'] = include __DIR__ . '/../Settings/pos.php';

            return $tabs;
        });

        Event::listen(RenderFooterEvent::class, RenderFooterListener::class);
        Event::listen(SettingsSavedEvent::class, function (SettingsSavedEvent $event) {
            $keys = array_keys((array) $event->data);

            foreach ($keys as $key) {
                if (Str::startsWith($key, 'ns_special_')) {
                    app(SpecialCustomerService::class)->clearConfigCache();
                    break;
                }
            }
        });

        // Register POS hooks for special customer functionality
        $this->registerPOSHooks();
    }

    /**
     * Register POS integration hooks
     * Only uses core hooks that are actually called by NexoPOS
     */
    private function registerPOSHooks(): void
    {
        // POS Options Hook - inject special customer configuration
        // This hook is called during POS initialization
        Hook::addFilter('ns-pos-options', function ($options) {
            $specialCustomerService = app(SpecialCustomerService::class);
            $config = $specialCustomerService->getConfig();
            
            $options['specialCustomer'] = [
                'enabled' => !is_null($config['groupId']),
                'groupId' => $config['groupId'],
                'discountPercentage' => $config['discountPercentage'],
                'cashbackPercentage' => $config['cashbackPercentage'],
                'applyDiscountStackable' => $config['applyDiscountStackable'],
            ];

            return $options;
        });

        // Order Creation Hook - enforce special customer discount on backend
        // This is the ONLY reliable way to ensure discount is applied
        Hook::addFilter('ns-orders-before-create', function ($fields) {
            $customerId = $fields['customer_id'] ?? null;
            
            if (!$customerId) {
                return $fields;
            }
            
            $customer = Customer::find($customerId);
            if (!$customer) {
                return $fields;
            }
            
            $specialCustomerService = app(SpecialCustomerService::class);
            
            // Check if customer is in special group
            if (!$specialCustomerService->isSpecialCustomer($customer)) {
                return $fields;
            }
            
            $config = $specialCustomerService->getConfig();
            $discountPercentage = $config['discountPercentage'] ?? 0;
            
            if ($discountPercentage <= 0) {
                return $fields;
            }
            
            // Calculate discount based on subtotal
            $subtotal = $fields['subtotal'] ?? 0;
            $discountAmount = $subtotal * ($discountPercentage / 100);
            
            // Apply discount to order fields
            $fields['discount_type'] = 'percentage';
            $fields['discount_percentage'] = $discountPercentage;
            $fields['discount_reason'] = 'Special Customer';
            
            \Log::info('Special customer discount enforced on order creation', [
                'customer_id' => $customerId,
                'subtotal' => $subtotal,
                'discount_percentage' => $discountPercentage,
                'discount_amount' => $discountAmount,
            ]);
            
            return $fields;
        });
    }
}


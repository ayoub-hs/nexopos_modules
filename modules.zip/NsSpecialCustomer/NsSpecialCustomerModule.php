<?php

namespace Modules\NsSpecialCustomer;

use App\Services\Module;

class NsSpecialCustomerModule extends Module
{
    public function __construct()
    {
        parent::__construct( __FILE__ );
    }
}

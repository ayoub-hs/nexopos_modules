@extends('layout.dashboard')

@section('layout.dashboard.body')
<div>
    @include(Hook::filter('ns-dashboard-header-file', '../common/dashboard-header'))
    <div id="dashboard-content" class="px-4">
        <div class="page-inner-header mb-4">
            <h3 class="text-3xl text-gray-800 font-bold">{{ __('Outstanding Tickets') }}</h3>
            <p class="text-gray-600">{{ __('Pay unpaid or partially paid orders directly from the special customer wallet.') }}</p>
        </div>

        <form method="GET" class="bg-white p-4 rounded shadow-sm mb-6">
            <div class="flex flex-wrap items-end gap-4">
                <div class="flex-1 min-w-[220px]">
                    <label class="block text-sm font-medium text-gray-700 mb-1">{{ __('Special Customer') }}</label>
                    <select name="customer_id" class="w-full border border-gray-300 rounded px-3 py-2">
                        <option value="">{{ __('Select a customer') }}</option>
                        @foreach($customers as $customer)
                            <option value="{{ $customer->id }}" @selected($selectedCustomer && $selectedCustomer->id === $customer->id)>
                                {{ $customer->first_name }} {{ $customer->last_name }} ({{ $customer->email }})
                            </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <button class="px-4 py-2 bg-blue-600 text-white rounded">{{ __('Load Tickets') }}</button>
                </div>
                @if($selectedCustomer)
                    <div class="text-sm text-gray-600">
                        <span class="font-semibold">{{ __('Wallet Balance:') }}</span>
                        {{ ns()->currency->fresh($selectedCustomer->account_amount) }}
                    </div>
                @endif
            </div>
        </form>

        <div class="bg-white rounded shadow-sm">
            <table class="w-full text-left">
                <thead>
                    <tr class="border-b">
                        <th class="px-4 py-3">{{ __('Order') }}</th>
                        <th class="px-4 py-3">{{ __('Date') }}</th>
                        <th class="px-4 py-3 text-right">{{ __('Total') }}</th>
                        <th class="px-4 py-3 text-right">{{ __('Paid') }}</th>
                        <th class="px-4 py-3 text-right">{{ __('Due') }}</th>
                        <th class="px-4 py-3">{{ __('Action') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($orders as $order)
                        <tr class="border-b">
                            <td class="px-4 py-3">#{{ $order->code }}</td>
                            <td class="px-4 py-3">{{ ns()->date->getFormatted($order->created_at) }}</td>
                            <td class="px-4 py-3 text-right">{{ ns()->currency->fresh($order->total) }}</td>
                            <td class="px-4 py-3 text-right">{{ ns()->currency->fresh($order->paid_amount) }}</td>
                            <td class="px-4 py-3 text-right">{{ ns()->currency->fresh($order->due_amount) }}</td>
                            <td class="px-4 py-3">
                                @if(ns()->allowedTo('special.customer.pay-outstanding-tickets'))
                                    <form method="POST" action="{{ route('ns.dashboard.special-customer-outstanding.pay') }}" onsubmit="return confirm('{{ __('Pay this ticket using the customer wallet?') }}')">
                                        @csrf
                                        <input type="hidden" name="customer_id" value="{{ $selectedCustomer?->id }}">
                                        <input type="hidden" name="order_id" value="{{ $order->id }}">
                                        <button class="px-3 py-1 bg-green-600 text-white rounded">
                                            {{ __('Pay from Wallet') }}
                                        </button>
                                    </form>
                                @else
                                    <span class="text-gray-500 text-sm">{{ __('Permission required to pay.') }}</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td class="px-4 py-4 text-gray-500" colspan="6">
                                {{ $selectedCustomer ? __('No outstanding tickets found.') : __('Select a customer to view tickets.') }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

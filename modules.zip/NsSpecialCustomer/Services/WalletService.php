<?php

namespace Modules\NsSpecialCustomer\Services;

use App\Models\Customer;
use App\Models\CustomerAccountHistory;
use App\Services\CustomerService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Carbon\Carbon;
use Modules\NsSpecialCustomer\Services\AuditService;

class WalletService
{
    public function __construct(
        private CustomerService $customerService,
        private AuditService $auditService
    ) {}

    /**
     * Process top-up with double-entry ledger and transaction safety
     */
    public function processTopup(int $customerId, float $amount, string $description, string $reference = 'ns_special_topup'): array
    {
        return DB::transaction(function () use ($customerId, $amount, $description, $reference) {
            // Validate inputs
            if ($amount == 0) {
                return [
                    'success' => false,
                    'message' => 'Amount cannot be zero',
                    'transaction_id' => null,
                ];
            }

            $customer = Customer::query()
                ->where('id', $customerId)
                ->lockForUpdate()
                ->firstOrFail();

            $previousBalance = $customer->account_amount;
            $operation = $amount > 0
                ? CustomerAccountHistory::OPERATION_ADD
                : CustomerAccountHistory::OPERATION_DEDUCT;
            $amountValue = abs($amount);

            $result = $this->customerService->saveTransaction(
                customer: $customer,
                operation: $operation,
                amount: $amountValue,
                description: $description,
                details: [
                    'author' => auth()->id() ?? 1,
                    'reference' => $reference,
                ]
            );

            $customer->refresh();
            $newBalance = $customer->account_amount;

            // Clear customer cache
            $this->clearCustomerCache($customerId);

            $this->auditService->logTopupOperation(
                customerId: $customerId,
                amount: $amount,
                operation: $amount > 0 ? 'credit' : 'debit',
                metadata: [
                    'reference' => $reference,
                    'previous_balance' => $previousBalance,
                    'new_balance' => $newBalance,
                ]
            );

            return [
                'success' => true,
                'message' => 'Transaction processed successfully',
                'transaction_id' => $result['data']['customerAccountHistory']->id ?? null,
                'previous_balance' => $previousBalance,
                'new_balance' => $newBalance,
                'amount' => $amount,
            ];
        });
    }

    /**
     * Get customer balance with caching
     */
    public function getBalance(int $customerId): float
    {
        return Cache::remember("ns_special_customer_balance_{$customerId}", 300, function () use ($customerId) {
            $customer = Customer::find($customerId);
            return $customer ? (float) $customer->account_amount : 0.0;
        });
    }

    /**
     * Get transaction history with filters
     */
    public function getTransactionHistory(int $customerId, array $filters = [], int $perPage = 50): array
    {
        $query = CustomerAccountHistory::where('customer_id', $customerId)
            ->orderBy('created_at', 'desc');

        // Apply filters
        if (!empty($filters['operation'])) {
            $query->where('operation', $filters['operation']);
        }

        if (!empty($filters['reference'])) {
            $query->where('reference', $filters['reference']);
        }

        if (!empty($filters['date_from'])) {
            $query->whereDate('created_at', '>=', $filters['date_from']);
        }

        if (!empty($filters['date_to'])) {
            $query->whereDate('created_at', '<=', $filters['date_to']);
        }

        if (!empty($filters['min_amount'])) {
            $query->where('amount', '>=', $filters['min_amount']);
        }

        if (!empty($filters['max_amount'])) {
            $query->where('amount', '<=', $filters['max_amount']);
        }

        return $query->paginate($perPage)->toArray();
    }

    /**
     * Record ledger entry with audit trail
     */
    public function recordLedgerEntry(
        int $customerId,
        float $debitAmount,
        float $creditAmount,
        string $description,
        ?int $orderId = null,
        string $reference = 'ns_special_ledger'
    ): array {
        return DB::transaction(function () use ($customerId, $debitAmount, $creditAmount, $description, $orderId, $reference) {
            if ($debitAmount > 0 && $creditAmount > 0) {
                throw new \Exception('Cannot have both debit and credit amounts in single entry');
            }

            $amount = $debitAmount > 0 ? -$debitAmount : $creditAmount;
            $operation = $debitAmount > 0 ? 'DEBIT' : 'CREDIT';

            return $this->processTopup($customerId, $amount, $description, $reference);
        });
    }

    /**
     * Validate balance before operation
     */
    public function validateBalance(int $customerId, float $requiredAmount): array
    {
        $currentBalance = $this->getBalance($customerId);
        
        return [
            'sufficient' => $currentBalance >= $requiredAmount,
            'current_balance' => $currentBalance,
            'required_amount' => $requiredAmount,
            'shortfall' => max(0, $requiredAmount - $currentBalance),
        ];
    }

    /**
     * Get balance summary for dashboard
     */
    public function getBalanceSummary(int $customerId): array
    {
        $cacheKey = "ns_special_customer_balance_summary_{$customerId}";
        
        return Cache::remember($cacheKey, 600, function () use ($customerId) {
            $customer = Customer::find($customerId);
            if (!$customer) {
                return [
                    'balance' => 0,
                    'total_credit' => 0,
                    'total_debit' => 0,
                    'transaction_count' => 0,
                    'last_transaction' => null,
                ];
            }

            $transactions = CustomerAccountHistory::where('customer_id', $customerId);
            $creditOperations = [
                CustomerAccountHistory::OPERATION_ADD,
                CustomerAccountHistory::OPERATION_REFUND,
                'CREDIT',
            ];
            $debitOperations = [
                CustomerAccountHistory::OPERATION_DEDUCT,
                CustomerAccountHistory::OPERATION_PAYMENT,
                'DEBIT',
            ];
            
            $summary = [
                'balance' => (float) $customer->account_amount,
                'total_credit' => $transactions->whereIn('operation', $creditOperations)->sum('amount'),
                'total_debit' => abs($transactions->whereIn('operation', $debitOperations)->sum('amount')),
                'transaction_count' => $transactions->count(),
                'last_transaction' => $transactions->latest()->first(),
                'recent_transactions' => $transactions->latest()->limit(5)->get(),
            ];

            return $summary;
        });
    }

    /**
     * Get daily balance changes for reporting
     */
    public function getDailyBalanceChanges(int $customerId, int $days = 30): array
    {
        $cacheKey = "ns_special_customer_daily_balance_{$customerId}_{$days}";
        
        return Cache::remember($cacheKey, 1800, function () use ($customerId, $days) {
            $startDate = now()->subDays($days)->startOfDay();
            
            $changes = CustomerAccountHistory::where('customer_id', $customerId)
                ->where('created_at', '>=', $startDate)
                ->selectRaw('
                    DATE(created_at) as date,
                    SUM(CASE WHEN operation IN ("add", "refund", "CREDIT") THEN amount ELSE 0 END) as credits,
                    SUM(CASE WHEN operation IN ("deduct", "payment", "DEBIT") THEN ABS(amount) ELSE 0 END) as debits,
                    COUNT(*) as transaction_count
                ')
                ->groupBy('date')
                ->orderBy('date')
                ->get();

            return $changes->toArray();
        });
    }

    /**
     * Reconcile customer balance
     */
    public function reconcileBalance(int $customerId): array
    {
        return DB::transaction(function () use ($customerId) {
            $customer = Customer::findOrFail($customerId);
            $calculatedBalance = CustomerAccountHistory::where('customer_id', $customerId)
                ->sum('amount');

            $currentBalance = $customer->account_amount;
            $discrepancy = $calculatedBalance - $currentBalance;

            if (abs($discrepancy) < 0.01) {
                return [
                    'reconciled' => true,
                    'message' => 'Balance is already reconciled',
                    'current_balance' => $currentBalance,
                    'calculated_balance' => $calculatedBalance,
                    'discrepancy' => $discrepancy,
                ];
            }

            // Create reconciliation entry
            $reconciliationDescription = "Balance reconciliation. Discrepancy: {$discrepancy}";
            
            $this->processTopup(
                $customerId,
                $discrepancy,
                $reconciliationDescription,
                'ns_special_reconciliation'
            );

            // Clear cache
            $this->clearCustomerCache($customerId);

            return [
                'reconciled' => true,
                'message' => 'Balance reconciled successfully',
                'current_balance' => $currentBalance,
                'calculated_balance' => $calculatedBalance,
                'discrepancy' => $discrepancy,
                'new_balance' => $currentBalance + $discrepancy,
            ];
        });
    }

    /**
     * Get wallet statistics for reporting
     */
    public function getWalletStatistics(?int $customerId = null): array
    {
        $cacheKey = "ns_special_wallet_stats_" . ($customerId ?? 'all');
        
        return Cache::remember($cacheKey, 3600, function () use ($customerId) {
            $query = CustomerAccountHistory::query();
            
            if ($customerId) {
                $query->where('customer_id', $customerId);
            }

            $creditOperations = [
                CustomerAccountHistory::OPERATION_ADD,
                CustomerAccountHistory::OPERATION_REFUND,
                'CREDIT',
            ];
            $debitOperations = [
                CustomerAccountHistory::OPERATION_DEDUCT,
                CustomerAccountHistory::OPERATION_PAYMENT,
                'DEBIT',
            ];

            $stats = [
                'total_transactions' => $query->count(),
                'total_credits' => $query->whereIn('operation', $creditOperations)->sum('amount'),
                'total_debits' => abs($query->whereIn('operation', $debitOperations)->sum('amount')),
                'net_flow' => $query->sum('amount'),
                'average_transaction' => $query->avg('amount'),
                'largest_credit' => $query->whereIn('operation', $creditOperations)->max('amount'),
                'largest_debit' => $query->whereIn('operation', $debitOperations)->min('amount'),
            ];

            if ($customerId) {
                $customer = Customer::find($customerId);
                $stats['current_balance'] = $customer ? $customer->account_amount : 0;
            }

            return $stats;
        });
    }

    /**
     * Clear customer-specific cache
     */
    private function clearCustomerCache(int $customerId): void
    {
        Cache::forget("ns_special_customer_balance_{$customerId}");
        Cache::forget("ns_special_customer_balance_summary_{$customerId}");
        
        // Clear daily balance cache
        foreach ($this->getCacheKeys("*ns_special_customer_daily_balance_{$customerId}_*") as $key) {
            Cache::forget($key);
        }
    }

    /**
     * Clear all wallet cache
     */
    public function clearAllCache(): void
    {
        foreach ($this->getCacheKeys('*ns_special_customer_balance*') as $key) {
            Cache::forget($key);
        }
        
        foreach ($this->getCacheKeys('*ns_special_wallet_stats*') as $key) {
            Cache::forget($key);
        }
    }

    /**
     * Safely fetch cache keys for Redis-backed stores.
     */
    private function getCacheKeys(string $pattern): array
    {
        $store = Cache::getStore();

        if (method_exists($store, 'getRedis')) {
            $redis = $store->getRedis();

            if (is_object($redis) && method_exists($redis, 'keys')) {
                return $redis->keys($pattern);
            }
        }

        return [];
    }
}

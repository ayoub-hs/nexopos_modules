<?php

namespace Modules\NsManufacturing\Services;

use TorMorten\Eventy\Facades\Events as Hook;

class ProductFormHook
{
    public function __construct()
    {
        // Register hooks for product form modifications
        $this->registerHooks();
    }

    /**
     * Register all hooks for product form modifications
     */
    private function registerHooks(): void
    {
        // Hook into product CRUD form
        Hook::addFilter('ns-products-crud-form', [$this, 'addManufacturingFieldsToProductForm']);
        
        // Hook into product CRUD columns
        Hook::addFilter('ns-products-crud-columns', [$this, 'addManufacturingColumnsToProductTable']);
        
        // Hook into product CRUD validation
        Hook::addFilter('ns-products-crud-validate-post', [$this, 'validateManufacturingFlags']);
        Hook::addFilter('ns-products-crud-validate-put', [$this, 'validateManufacturingFlags']);
    }

    /**
     * Add manufacturing fields to the product form
     * 
     * @param array $form
     * @return array
     */
    public function addManufacturingFieldsToProductForm(array $form): array
    {
        // Add manufacturing tab if it doesn't exist
        $hasManufacturingTab = false;
        foreach ($form['variations'][0]['tabs'] as $tab) {
            if (isset($tab['label']) && $tab['label'] === __('Manufacturing')) {
                $hasManufacturingTab = true;
                break;
            }
        }

        if (!$hasManufacturingTab) {
            // Add manufacturing tab before the last tab (usually images)
            $lastTab = array_pop($form['variations'][0]['tabs']);
            $form['variations'][0]['tabs'][] = [
                'label' => __('Manufacturing'),
                'fields' => [
                    [
                        'type' => 'switch',
                        'name' => 'is_manufactured',
                        'label' => __('Is Manufactured'),
                        'description' => __('Check if this product can be manufactured (used for production)'),
                        'value' => '0',
                        'options' => Helper::boolToOptions(
                            true: __( 'Yes' ),
                            false: __( 'No' ),
                        ),
                    ],
                    [
                        'type' => 'switch',
                        'name' => 'is_raw_material',
                        'label' => __('Is Raw Material'),
                        'description' => __('Check if this product is a raw material (can be used as component)'),
                        'value' => '0',
                        'options' => Helper::boolToOptions(
                            true: __( 'Yes' ),
                            false: __( 'No' ),
                        ),
                    ],
                    [
                        'type' => 'help',
                        'content' => __('Note: At least one manufacturing flag must be selected. Manufactured products can be used for production, while both manufactured products and raw materials can be used as components.'),
                    ],
                ],
            ];
            
            // Add back the last tab
            $form['variations'][0]['tabs'][] = $lastTab;
        }

        return $form;
    }

    /**
     * Add manufacturing columns to the product table
     * 
     * @param array $columns
     * @return array
     */
    public function addManufacturingColumnsToProductTable(array $columns): array
    {
        // Add manufacturing columns after the type column
        $newColumns = [];
        foreach ($columns as $key => $column) {
            $newColumns[$key] = $column;
            
            // Insert manufacturing columns after type
            if ($key === 'type') {
                $newColumns['is_manufactured'] = [
                    'label' => __('Manufactured'),
                    '$direction' => '',
                    '$sort' => false,
                    'width' => '120px',
                ];
                $newColumns['is_raw_material'] = [
                    'label' => __('Raw Material'),
                    '$direction' => '',
                    '$sort' => false,
                    'width' => '120px',
                ];
            }
        }
        
        return $newColumns;
    }

    /**
     * Validate manufacturing flags before saving
     * 
     * @param array $inputs
     * @param mixed $entry
     * @return array
     */
    public function validateManufacturingFlags(array $inputs, $entry = null): array
    {
        // Check if at least one manufacturing flag is selected
        if (empty($inputs['is_manufactured']) && empty($inputs['is_raw_material'])) {
            throw new \Exception(__('At least one manufacturing flag must be selected (Is Manufactured or Is Raw Material).'));
        }
        
        return $inputs;
    }
}
<?php

namespace Modules\NsManufacturing\Services;

use TorMorten\Eventy\Facades\Events as Hook;

class ProductUnitFormHook
{
    public function __construct()
    {
        // Register hooks for product unit form modifications
        $this->registerHooks();
    }

    /**
     * Register all hooks for product unit form modifications
     */
    private function registerHooks(): void
    {
        // Hook into product unit quantities form
        Hook::addFilter('ns.products-units-crud-form', [$this, 'addManufacturingFieldsToProductUnitForm']);
        
        // Hook into product unit quantities columns
        Hook::addFilter('ns.products-units-crud-columns', [$this, 'addManufacturingColumnsToProductUnitTable']);
        
        // Hook into product unit quantities actions
        Hook::addFilter('ns.products-units-crud-set-actions', [$this, 'addManufacturingActionsToProductUnit'], 10, 2);
    }

    /**
     * Add manufacturing fields to the product unit form
     * 
     * @param array $form
     * @return array
     */
    public function addManufacturingFieldsToProductUnitForm(array $form): array
    {
        // Add manufacturing tab if it doesn't exist
        $hasManufacturingTab = false;
        foreach ($form['tabs'] as $tab) {
            if (isset($tab['label']) && $tab['label'] === __('Manufacturing')) {
                $hasManufacturingTab = true;
                break;
            }
        }

        if (!$hasManufacturingTab) {
            // Add manufacturing tab after the first tab (usually general)
            $firstTab = array_shift($form['tabs']);
            $form['tabs'] = [$firstTab];
            
            $form['tabs'][] = [
                'label' => __('Manufacturing'),
                'fields' => [
                    [
                        'type' => 'switch',
                        'name' => 'is_manufactured',
                        'label' => __('Is Manufactured'),
                        'description' => __('Check if this product can be manufactured (used for production)'),
                        'value' => '0',
                        'options' => [
                            'yes' => __('Yes'),
                            'no' => __('No'),
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'name' => 'is_raw_material',
                        'label' => __('Is Raw Material'),
                        'description' => __('Check if this product is a raw material (can be used as component)'),
                        'value' => '0',
                        'options' => [
                            'yes' => __('Yes'),
                            'no' => __('No'),
                        ],
                    ],
                    [
                        'type' => 'help',
                        'content' => __('Note: At least one manufacturing flag must be selected. Manufactured products can be used for production, while both manufactured products and raw materials can be used as components.'),
                    ],
                ],
            ];
            
            // Add back the remaining tabs
            foreach ($form['tabs'] as $tab) {
                if (!isset($tab['label']) || $tab['label'] !== __('Manufacturing')) {
                    $form['tabs'][] = $tab;
                }
            }
        }

        return $form;
    }

    /**
     * Add manufacturing columns to the product unit table
     * 
     * @param array $columns
     * @return array
     */
    public function addManufacturingColumnsToProductUnitTable(array $columns): array
    {
        // Add manufacturing columns after the quantity column
        $newColumns = [];
        foreach ($columns as $key => $column) {
            $newColumns[$key] = $column;
            
            // Insert manufacturing columns after quantity
            if ($key === 'quantity') {
                $newColumns['is_manufactured'] = [
                    'label' => __('Manufactured'),
                    '$direction' => '',
                    '$sort' => false,
                ];
                $newColumns['is_raw_material'] = [
                    'label' => __('Raw Material'),
                    '$direction' => '',
                    '$sort' => false,
                ];
            }
        }
        
        return $newColumns;
    }

    /**
     * Add manufacturing actions to product unit entries
     * 
     * @param mixed $entry
     * @param mixed $crud
     * @return mixed
     */
    public function addManufacturingActionsToProductUnit($entry, $crud)
    {
        // Add manufacturing-specific actions if the entry has manufacturing flags
        if (isset($entry->is_manufactured) || isset($entry->is_raw_material)) {
            // Add manufacturing details action
            $entry->action(
                identifier: 'manufacturing_details',
                label: '<i class="las fa-cogs"></i> ' . __('Manufacturing'),
                url: ns()->url('/dashboard/manufacturing/product-unit-details?id=' . $entry->id),
            );
        }
        
        return $entry;
    }

    /**
     * Validate manufacturing flags before saving
     * 
     * @param array $inputs
     * @param mixed $entry
     * @return array
     */
    public function validateManufacturingFlags(array $inputs, $entry = null): array
    {
        // Check if at least one manufacturing flag is selected
        if (empty($inputs['is_manufactured']) && empty($inputs['is_raw_material'])) {
            throw new \Exception(__('At least one manufacturing flag must be selected (Is Manufactured or Is Raw Material).'));
        }
        
        return $inputs;
    }
}